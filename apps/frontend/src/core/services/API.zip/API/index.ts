import { singleAPI } from './app/single.api'
import { subjectsAPI } from './subjects/subjects.api'

export const API = {
  single: singleAPI,
  subjects: subjectsAPI,
}

export type API = typeof API
